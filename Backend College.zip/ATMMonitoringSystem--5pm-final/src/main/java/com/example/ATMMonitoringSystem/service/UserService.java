package com.example.ATMMonitoringSystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.ATMMonitoringSystem.model.User;
import com.example.ATMMonitoringSystem.repository.UserRepository;

@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    /**
     * Authenticates a user by email and password
     * 
     * @param email the user's email used for authentication
     * @param password the user's password
     * @return User object if authentication successful, null otherwise
     */
    public User authenticateUser(String email, String password) {
        User user = userRepository.findByUserId(email);
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return user;
        }
        return null;
    }
    
    /**
     * Creates a new user account
     * 
     * @param user the user object to create
     * @return the created user
     */
    public User createUser(User user) {
        // Check if user already exists
        User existingUser = userRepository.findByUserId(user.getUserId());
        if (existingUser != null) {
            throw new RuntimeException("User with this email already exists");
        }
        
        // Encode both password and security answer
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setSecurityAnswer(passwordEncoder.encode(user.getSecurityAnswer()));
        
        return userRepository.save(user);
    }

    /**
     * Verifies the security answer for a user
     * 
     * @param email the user's email
     * @param securityAnswer the security answer to verify
     * @return true if the security answer matches, false otherwise
     */
    public boolean verifySecurityAnswer(String email, String securityAnswer) {
        User user = userRepository.findByUserId(email);
        return user != null && passwordEncoder.matches(securityAnswer, user.getSecurityAnswer());
    }

    /**
     * Resets the password for a user
     * 
     * @param email the user's email
     * @param newPassword the new password to set
     * @return true if the password was successfully reset, false otherwise
     */
    public boolean resetPassword(String email, String newPassword) {
        User user = userRepository.findByUserId(email);
        if (user != null) {
            // Encode the new password before saving
            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);
            return true;
        }
        return false;
    }
}
