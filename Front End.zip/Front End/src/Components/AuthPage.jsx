import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./AuthPage.css";
const API_BASE_URL = "http://localhost:8081/api";
 
const EmailIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mr-2">
    <path d="M22 6C22 4.9 21.1 4 20 4H4C2.9 4 2 4.9 2 6V18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6ZM20 6L12 11L4 6H20ZM20 18H4V8L12 13L20 8V18Z" fill="currentColor" />
  </svg>
);
 
const LockIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mr-2">
    <path d="M18 8H17V6C17 3.24 14.76 1 12 1C9.24 1 7 3.24 7 6V8H6C4.9 8 4 8.9 4 10V20C4 21.1 4.9 22 6 22H18C19.1 22 20 21.1 20 20V10C20 8.9 19.1 8 18 8ZM12 17C10.9 17 10 16.1 10 15C10 13.9 10.9 13 12 13C13.1 13 14 13.9 14 15C14 16.1 13.1 17 12 17ZM15.1 8H8.9V6C8.9 4.29 10.29 2.9 12 2.9C13.71 2.9 15.1 4.29 15.1 6V8Z" fill="currentColor" />
  </svg>
);
 
const PersonIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mr-2">
    <path d="M12 12C14.21 12 16 10.21 16 8C16 5.79 14.21 4 12 4C9.79 4 8 5.79 8 8C8 10.21 9.79 12 12 12ZM12 14C9.33 14 4 15.34 4 18V20H20V18C20 15.34 14.67 14 12 14Z" fill="currentColor" />
  </svg>
);
 
const RoleIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mr-2">
    <path d="M19 3H5C4.9 3 4 3.9 4 5V19C4 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19ZM7 10H9V17H7V10ZM11 7H13V17H11V7ZM15 13H17V17H15V13Z" fill="currentColor" />
  </svg>
);
 
const AuthPage = () => {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
 
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [showForgotDialog, setShowForgotDialog] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [resetSuccess, setResetSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
 
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [confirmPasswordError, setConfirmPasswordError] = useState("");
  const [isCheckingEmail, setIsCheckingEmail] = useState(false);
  const [registrationSecurityAnswer, setRegistrationSecurityAnswer] = useState("");
 
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [securityAnswer, setSecurityAnswer] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmResetPassword, setConfirmResetPassword] = useState("");
  const [resetPasswordError, setResetPasswordError] = useState("");
  const [isAnswerVerified, setIsAnswerVerified] = useState(false);
  const [isCheckingAnswer, setIsCheckingAnswer] = useState(false);
 
  // Add new state variables
  const [newPasswordError, setNewPasswordError] = useState("");
  const [confirmResetPasswordError, setConfirmResetPasswordError] = useState("");
 
  const handleShowPassword = () => setShowPassword(!showPassword);
 
  useEffect(() => {
    document.body.style.overflow = "hidden";
 
    return () => {
      document.body.style.overflow = "";
    };
  }, []);
 
  const validateEmail = () => {
    if (!email.includes("@")) {
      setEmailError("Invalid email address");
      return false;
    } else {
      setEmailError("");
      return true;
    }
  };
 
  const validatePassword = () => {
    if (isLogin) return true;
 
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{4,12}$/;
    if (!passwordRegex.test(password)) {
      setPasswordError(
        "Password must be 4-12 characters with at least one capital letter, one number, and one special character."
      );
      return false;
    } else {
      setPasswordError("");
      return true;
    }
  };
 
  const validateConfirmPassword = () => {
    if (isLogin) return true;
 
    if (password !== confirmPassword) {
      setConfirmPasswordError("Passwords do not match");
      return false;
    } else {
      setConfirmPasswordError("");
      return true;
    }
  };
 
  const validateNewPassword = () => {
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{4,12}$/;
    if (!passwordRegex.test(newPassword)) {
      setNewPasswordError(
        "Password must be 4-12 characters with at least one capital letter, one number, and one special character."
      );
      return false;
    }
    setNewPasswordError("");
    return true;
  };
 
  const validateConfirmResetPassword = () => {
    if (newPassword !== confirmResetPassword) {
      setConfirmResetPasswordError("Passwords do not match");
      return false;
    }
    setConfirmResetPasswordError("");
    return true;
  };
 
  const checkEmailAvailability = async () => {
    if (isLogin || !validateEmail()) return;
 
    setIsCheckingEmail(true);
 
    try {
      const response = await fetch(`${API_BASE_URL}/auth/check-email?email=${encodeURIComponent(email)}`);
      const data = await response.json();
 
      if (data.exists) {
        setEmailError("This email is already registered");
        return false;
      } else {
        setEmailError("");
        return true;
      }
    } catch (error) {
      console.error("Error checking email:", error);
 
      return true;
    } finally {
      setIsCheckingEmail(false);
    }
  };
 
  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);
 
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });
 
      const data = await response.json();
 
      if (response.ok) {
        localStorage.setItem("userRole", data.role || "user");
        localStorage.setItem("userName", data.name || email.split("@")[0]);
        localStorage.setItem("userToken", data.token || "demo-token");
        navigate("/dashboard");
      } else {
        setError(data.message || "Invalid credentials");
      }
    } catch (err) {
      console.error("Fetch error:", err);
      setError("Login failed. Please check your connection or credentials.");
    } finally {
      setIsLoading(false);
    }
  };
 
  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);
 
    // Add security answer validation
    if (!registrationSecurityAnswer.trim()) {
      setError("Security question answer is required");
      setIsLoading(false);
      return;
    }
 
    const isEmailValid = validateEmail();
    const isPasswordValid = validatePassword();
    const isConfirmPasswordValid = validateConfirmPassword();
    const isEmailAvailable = await checkEmailAvailability();
 
    if (!isEmailValid || !isPasswordValid || !isConfirmPasswordValid || !isEmailAvailable) {
      setIsLoading(false);
      return;
    }
 
    if (!name || !email || !role || !password || !confirmPassword || !registrationSecurityAnswer.trim()) {
      setError("All fields are required");
      setIsLoading(false);
      return;
    }
 
    try {
      const registrationData = {
        name: name,
        email: email,
        password: password,
        role: role,
        securityAnswer: registrationSecurityAnswer.trim(), // Ensure trimmed value is sent
      };
 
      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(registrationData),
      });
 
      const data = await response.json();
 
      if (response.ok) {
        setIsLogin(true);
        setError("");
        setName("");
        setEmail("");
        setPassword("");
        setRole("");
        setConfirmPassword("");
        setRegistrationSecurityAnswer("");
        setError("Registration successful! Please login.");
      } else {
        setError(data.message || "Registration failed. Please try again.");
      }
    } catch (error) {
      console.error("Registration error:", error);
      setError("Registration failed. Please check your connection and try again.");
    } finally {
      setIsLoading(false);
    }
  };
 
  const handleForgotPassword = async (e) => {
    e.preventDefault();
 
    if (!resetEmail) {
      setError("Please enter your email address");
      return;
    }
 
    setResetSuccess(true);
    setTimeout(() => {
      setShowForgotDialog(false);
      setResetSuccess(false);
      setResetEmail("");
    }, 3000);
  };
 
  const handleVerifyAnswer = async (e) => {
    e.preventDefault();
    setIsCheckingAnswer(true);
    setResetPasswordError("");
 
    try {
      const response = await fetch(`${API_BASE_URL}/auth/verify-security-answer`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: resetEmail, securityAnswer }),
      });
 
      const data = await response.json();
 
      if (response.ok && data.isValid) {
        setIsAnswerVerified(true);
      } else {
        setResetPasswordError("Invalid email or security answer. Please try again.");
      }
    } catch (error) {
      setResetPasswordError("Failed to verify. Please try again.");
    } finally {
      setIsCheckingAnswer(false);
    }
  };
 
  const handleResetPassword = async (e) => {
    e.preventDefault();
    setResetPasswordError("");
 
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{4,12}$/;
    if (!passwordRegex.test(newPassword)) {
      setResetPasswordError(
        "Password must be 4-12 characters with at least one capital letter, one number, and one special character."
      );
      return;
    }
 
    if (newPassword !== confirmResetPassword) {
      setResetPasswordError("Passwords do not match");
      return;
    }
 
    try {
      const response = await fetch(`${API_BASE_URL}/auth/reset-password`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: resetEmail,
          newPassword: newPassword
        }),
      });
 
      const data = await response.json();
 
      if (response.ok) {
        setShowResetDialog(false);
        setError("Password reset successful! Please login with your new password.");
        // Clear all reset-related states
        setResetEmail("");
        setNewPassword("");
        setConfirmResetPassword("");
        setIsAnswerVerified(false);
      } else {
        setResetPasswordError(data.message || "Failed to reset password. Please try again.");
      }
    } catch (error) {
      setResetPasswordError("Failed to reset password. Please try again.");
    }
  };
 
  return (
    <div className="auth-container">
      <div className={`auth-card ${isLogin ? "card-login" : "card-register"}`}>
        <h1 className="auth-heading">ATM Monitoring System</h1>
        <p className="auth-subheading">{isLogin ? "Welcome Back! Login to continue" : "Create an account"}</p>
 
        {error && <div className={error.includes("successful") ? "auth-success" : "auth-error"}>{error}</div>}
 
        {isLogin ? (
          <form onSubmit={handleLogin}>
            <div className="input-group">
              <label className="auth-label">Email Address</label>
              <div className="input-wrapper">
                <EmailIcon />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="auth-input"
                  placeholder="Enter email"
                />
              </div>
            </div>
 
            <div className="input-group">
              <label className="auth-label">Password</label>
              <div className="input-wrapper">
                <LockIcon />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="auth-input"
                  placeholder="Enter password"
                />
                <button
                  type="button"
                  onClick={handleShowPassword}
                  className="show-password-btn"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                ></button>
              </div>
            </div>
 
            <div className="input-group">
              <button
                type="button"
                className="reset-password-link"
                onClick={() => setShowResetDialog(true)}
              >
                Forgot Password?
              </button>
            </div>
 
            <button type="submit" className="auth-button" disabled={isLoading}>
              {isLoading ? "Signing In..." : "Sign In"}
            </button>
 
            <div className="auth-footer">
              <button type="button" className="toggle-link" onClick={() => setIsLogin(false)}>
                Need an account? Register
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleRegister}>
            <div className="input-group">
              <label className="auth-label">Full Name</label>
              <div className="input-wrapper">
                <PersonIcon />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="auth-input"
                  placeholder="Enter your name"
                />
              </div>
            </div>
 
            <div className="input-group">
              <label className="auth-label">Email Address</label>
              <div className="input-wrapper">
                <EmailIcon />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onBlur={checkEmailAvailability}
                  required
                  className="auth-input"
                  placeholder="Enter your email"
                />
                {isCheckingEmail && <span className="loading-indicator">Checking...</span>}
              </div>
              {emailError && <p className="field-error">{emailError}</p>}
            </div>
 
            <div className="input-group">
              <label className="auth-label">Role</label>
              <div className="select-wrapper">
                <RoleIcon />
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  required
                  className="auth-select"
                >
                  <option value="" disabled hidden className="auth-option">
                    Select Role
                  </option>
                  <option value="admin" className="auth-option">
                    Admin
                  </option>
                  <option value="tech" className="auth-option">
                    Technician
                  </option>
                </select>
              </div>
            </div>
 
            <div className="input-group">
              <label className="auth-label">What is your first school?</label>
              <div className="input-wrapper">
                <input
                  type="text"
                  className="auth-input"
                  value={registrationSecurityAnswer}
                  onChange={(e) => setRegistrationSecurityAnswer(e.target.value)}
                  required
                  placeholder="Enter your answer"
                />
              </div>
            </div>
 
            <div className="flex-row">
              <div className="flex-column input-group">
                <label className="auth-label">Password</label>
                <div className="input-wrapper">
                  <LockIcon />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onBlur={validatePassword}
                    required
                    className="auth-input"
                    placeholder="Create password"
                  />
                </div>
                {passwordError && <p className="field-error">{passwordError}</p>}
              </div>
 
              <div className="flex-column input-group">
                <label className="auth-label">Confirm</label>
                <div className="input-wrapper">
                  <LockIcon />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    onBlur={validateConfirmPassword}
                    required
                    className="auth-input"
                    placeholder="Confirm password"
                  />
                </div>
                {confirmPasswordError && <p className="field-error">{confirmPasswordError}</p>}
              </div>
            </div>
 
            <div className="checkbox-container">
              <input type="checkbox" checked={showPassword} onChange={handleShowPassword} id="showPassword" />
              <label htmlFor="showPassword">Show passwords</label>
            </div>
 
            <button type="submit" className="auth-button" disabled={isLoading}>
              {isLoading ? "Registering..." : "Register"}
            </button>
 
            <div className="auth-footer">
              <button type="button" className="toggle-link" onClick={() => setIsLogin(true)}>
                Already have an account? Sign in
              </button>
              <span></span>
            </div>
          </form>
        )}
      </div>
 
      {showForgotDialog && (
        <div className="auth-overlay">
          <div className="auth-dialog">
            <h2 className="dialog-title">Reset Password</h2>
 
            {resetSuccess ? (
              <div className="success-message">Password reset link has been sent to your email.</div>
            ) : (
              <>
                <p className="dialog-text">
                  Enter your email address and we'll send you a link to reset your password.
                </p>
 
                <input
                  type="email"
                  placeholder="Email Address"
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  className="dialog-input"
                />
 
                <div className="dialog-buttons">
                  <button className="dialog-btn cancel-btn" onClick={() => setShowForgotDialog(false)}>
                    Cancel
                  </button>
                  <button className="dialog-btn submit-btn" onClick={handleForgotPassword}>
                    Send Link
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
 
      {showResetDialog && (
        <div className="auth-overlay">
          <div className="auth-dialog reset-dialog">
            <h2 className="dialog-title">Reset Password</h2>
            {!isAnswerVerified ? (
              <form onSubmit={handleVerifyAnswer}>
                <div className="input-group">
                  <label className="auth-label">Email Address</label>
                  <div className="input-wrapper">
                    <EmailIcon />
                    <input
                      type="email"
                      className="auth-input"
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      required
                      placeholder="Enter your email"
                    />
                  </div>
                </div>
 
                <div className="input-group">
                  <label className="auth-label">What is your first school?</label>
                  <div className="input-wrapper">
                    <input
                      type="text"
                      className="auth-input"
                      value={securityAnswer}
                      onChange={(e) => setSecurityAnswer(e.target.value)}
                      required
                      placeholder="Enter your answer"
                    />
                  </div>
                </div>
 
                {resetPasswordError && <div className="auth-error">{resetPasswordError}</div>}
 
                <div className="dialog-buttons">
                  <button
                    type="button"
                    className="dialog-btn cancel-btn"
                    onClick={() => {
                      setShowResetDialog(false);
                      setResetPasswordError("");
                      setIsAnswerVerified(false);
                      setResetEmail("");
                      setSecurityAnswer("");
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="dialog-btn submit-btn"
                    disabled={isCheckingAnswer}
                  >
                    {isCheckingAnswer ? "Verifying..." : "Verify"}
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleResetPassword}>
                <div className="input-group">
                  <label className="auth-label">New Password</label>
                  <div className="input-wrapper">
                    <LockIcon />
                    <input
                      type={showPassword ? "text" : "password"}
                      className="auth-input"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      onBlur={validateNewPassword}
                      required
                      placeholder="Enter new password"
                    />
                  </div>
                  {newPasswordError && <p className="field-error">{newPasswordError}</p>}
                </div>
 
                <div className="input-group">
                  <label className="auth-label">Confirm Password</label>
                  <div className="input-wrapper">
                    <LockIcon />
                    <input
                      type={showPassword ? "text" : "password"}
                      className="auth-input"
                      value={confirmResetPassword}
                      onChange={(e) => setConfirmResetPassword(e.target.value)}
                      onBlur={validateConfirmResetPassword}
                      required
                      placeholder="Confirm new password"
                    />
                  </div>
                  {confirmResetPasswordError && (
                    <p className="field-error">{confirmResetPasswordError}</p>
                  )}
                </div>
 
                {resetPasswordError && <div className="auth-error">{resetPasswordError}</div>}
 
                <div className="dialog-buttons">
                  <button
                    type="button"
                    className="dialog-btn cancel-btn"
                    onClick={() => {
                      setShowResetDialog(false);
                      setResetPasswordError("");
                      setIsAnswerVerified(false);
                      setResetEmail("");
                      setSecurityAnswer("");
                    }}
                  >
                    Cancel
                  </button>
                  <button type="submit" className="dialog-btn submit-btn">
                    Reset Password
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
export default AuthPage;